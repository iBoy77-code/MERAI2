import tkinter as tk
from tkinter import messagebox

def to_binary(text):
    try:
        return ' '.join(format(ord(char), '08b') for char in text)
    except Exception as e:
        return f"Error: {str(e)}"

def convert():
    user_input = entry.get()
    if not user_input:
        messagebox.showwarning("Empty Field", "Please enter text or numbers.")
        return
    binary_output = to_binary(user_input)
    output_text.delete("1.0", tk.END)
    output_text.insert(tk.END, binary_output)

def copy_to_clipboard():
    root.clipboard_clear()
    root.clipboard_append(output_text.get("1.0", tk.END).strip())
    messagebox.showinfo("Copied", "Binary copied to clipboard!")

# GUI Setup
root = tk.Tk()
root.title("Project Binary Encoder - Zira")
root.geometry("500x400")
root.configure(bg="#1e1e1e")

# Title
title = tk.Label(root, text="🧠 Project Binary Encoder", font=("Consolas", 18, "bold"), fg="#00ff99", bg="#1e1e1e")
title.pack(pady=10)

# Input Field
entry = tk.Entry(root, font=("Consolas", 14), width=40, bg="#2e2e2e", fg="#ffffff", insertbackground="#00ff99")
entry.pack(pady=10)

# Convert Button
convert_btn = tk.Button(root, text="Convert to Binary", command=convert, font=("Consolas", 12), bg="#00ff99", fg="#000")
convert_btn.pack(pady=5)

# Output Text Area
output_text = tk.Text(root, height=10, font=("Consolas", 12), bg="#2e2e2e", fg="#00ff99", wrap="word")
output_text.pack(pady=10, padx=20)

# Copy Button
copy_btn = tk.Button(root, text="Copy Binary", command=copy_to_clipboard, font=("Consolas", 12), bg="#00ff99", fg="#000")
copy_btn.pack(pady=5)

# Run the App
root.mainloop()
