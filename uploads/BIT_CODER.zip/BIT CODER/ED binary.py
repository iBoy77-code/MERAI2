import tkinter as tk
from tkinter import messagebox

# Binary Encoding Function
def to_binary(text):
    try:
        return ' '.join(format(ord(char), '08b') for char in text)
    except Exception as e:
        return f"Error: {str(e)}"

# Binary Decoding Function
def from_binary(binary_input):
    try:
        binary_values = binary_input.strip().split()
        chars = [chr(int(b, 2)) for b in binary_values]
        return ''.join(chars)
    except Exception as e:
        return f"Error: Invalid binary input. {str(e)}"

# Conversion Handlers
def convert_to_binary():
    user_input = entry.get()
    if not user_input:
        messagebox.showwarning("Empty Field", "Please enter text or numbers.")
        return
    binary_output = to_binary(user_input)
    output_text.delete("1.0", tk.END)
    output_text.insert(tk.END, binary_output)

def convert_to_text():
    binary_input = binary_entry.get("1.0", tk.END)
    if not binary_input.strip():
        messagebox.showwarning("Empty Field", "Please enter binary to decode.")
        return
    decoded_text = from_binary(binary_input)
    decoded_output.delete(0, tk.END)
    decoded_output.insert(0, decoded_text)

# Copy Functions
def copy_binary():
    root.clipboard_clear()
    root.clipboard_append(output_text.get("1.0", tk.END).strip())
    messagebox.showinfo("Copied", "Binary copied to clipboard!")

def copy_text():
    root.clipboard_clear()
    root.clipboard_append(decoded_output.get().strip())
    messagebox.showinfo("Copied", "Decoded text copied to clipboard!")

# GUI Setup
root = tk.Tk()
root.title("🧠 Project Binary Encoder & Decoder - Zira")
root.geometry("600x600")
root.configure(bg="#1e1e1e")

# Title
title = tk.Label(root, text="🧠 Project Binary Encoder & Decoder", font=("Consolas", 18, "bold"), fg="#00ff99", bg="#1e1e1e")
title.pack(pady=10)

# ========== ENCODER SECTION ==========
encoder_label = tk.Label(root, text="🔵 Encode Text to Binary", font=("Consolas", 14), fg="#00ccff", bg="#1e1e1e")
encoder_label.pack(pady=(10, 0))

entry = tk.Entry(root, font=("Consolas", 14), width=50, bg="#2e2e2e", fg="#ffffff", insertbackground="#00ff99")
entry.pack(pady=5)

convert_btn = tk.Button(root, text="Convert to Binary", command=convert_to_binary, font=("Consolas", 12), bg="#00ff99", fg="#000")
convert_btn.pack(pady=5)

output_text = tk.Text(root, height=5, font=("Consolas", 12), bg="#2e2e2e", fg="#00ff99", wrap="word")
output_text.pack(pady=5, padx=20)

copy_binary_btn = tk.Button(root, text="Copy Binary", command=copy_binary, font=("Consolas", 12), bg="#00ff99", fg="#000")
copy_binary_btn.pack(pady=(0, 20))

# ========== DECODER SECTION ==========
decoder_label = tk.Label(root, text="🟢 Decode Binary to Text", font=("Consolas", 14), fg="#00ff99", bg="#1e1e1e")
decoder_label.pack(pady=(10, 0))

binary_entry = tk.Text(root, height=5, font=("Consolas", 12), bg="#2e2e2e", fg="#ffffff", wrap="word")
binary_entry.pack(pady=5, padx=20)

decode_btn = tk.Button(root, text="Decode to Text", command=convert_to_text, font=("Consolas", 12), bg="#00ff99", fg="#000")
decode_btn.pack(pady=5)

decoded_output = tk.Entry(root, font=("Consolas", 14), width=50, bg="#2e2e2e", fg="#00ff99", insertbackground="#00ff99")
decoded_output.pack(pady=5)

copy_text_btn = tk.Button(root, text="Copy Decoded Text", command=copy_text, font=("Consolas", 12), bg="#00ff99", fg="#000")
copy_text_btn.pack(pady=(0, 20))

# Run the App
root.mainloop()
